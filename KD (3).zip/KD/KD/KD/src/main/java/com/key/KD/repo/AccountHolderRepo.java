package com.key.KD.repo;

import com.key.KD.model.AccountHolder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountHolderRepo extends JpaRepository<AccountHolder, Long> {
}
