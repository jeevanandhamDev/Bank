package com.key.KD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KdApplication {
	public static void main(String[] args) {
		SpringApplication.run(KdApplication.class, args);
	}
}
