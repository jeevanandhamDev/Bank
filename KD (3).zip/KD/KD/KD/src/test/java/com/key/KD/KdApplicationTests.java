package com.key.KD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KdApplicationTests {

	@Test
	void contextLoads() {
	}

}
